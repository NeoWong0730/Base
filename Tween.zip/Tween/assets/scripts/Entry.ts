import { Sprite, SpriteAtlas, error, log, v3 } from 'cc';
import { _decorator, Component, Node, tween } from 'cc';
const { ccclass, property } = _decorator;


@ccclass('NodeItem')
class NodeItem {
    @property({ type: [Node] })
    nodes: Node[] = [];
}

@ccclass('Entry')
export class Entry extends Component {

    @property(SpriteAtlas)
    sprAtlas: SpriteAtlas = null;

    @property({ type: [NodeItem], tooltip: '[0,0]在左下角' })
    node_item: NodeItem[] = [];

    /** 列 */
    readonly row: number = 6;
    /** 行 */
    readonly line: number = 6;
    /** 各行初始y坐标 */
    readonly startPosY: number[] = [69, 209, 349, 489, 629, 769];
    /** 最下面看不见的y坐标 */
    readonly endPosY: number = -71;
    /** 最上面看不见的y坐标 */
    readonly topPosY: number = 769;
    /** 速度 */
    readonly actionSpeed: number = 2500;
    /** 一圈的时间 */
    readonly oneCircleTime: number = abs((this.endPosY - this.topPosY)) / this.actionSpeed;
    /** 圈数 */
    readonly circle: number = 8;
    /** item 高 */
    readonly itemHeight: number = 140;

    /** 播放中 */
    isPlaying: boolean;

    protected onLoad(): void {
        this.isPlaying = false;
        this.setRandItem();
    }

    setRandItem() {
        for (let i = 0; i < this.row; i++) {
            for (let j = 0; j < this.line; j++) {
                let spr = this.node_item[i].nodes[j].getChildByName('spr').getComponent(Sprite);
                let random = Math.ceil(Math.random() * 42);
                let sprF = this.sprAtlas.getSpriteFrame('spr' + random);
                spr.spriteFrame = sprF;
            }
        }
    }

    onClickSpin() {
        if (this.isPlaying) return;
        this.setRandItem();
        this.isPlaying = true;

        for (let i = 0; i < this.row; i++) {
            for (let j = 0; j < this.line; j++) {
                let t_node: Node = this.node_item[i].nodes[j];
                // 当前节点移动到看不见的y位置上需要的时间
                const nodeMoveEndPosYTime = abs(this.endPosY - this.startPosY[j]) / this.actionSpeed;
                // 转完圈数结束后，移动到自己原来的位置所需的时间
                let endPosYTime = abs(this.startPosY[j] - this.topPosY) / this.actionSpeed;
                // let endPosYyyyy = this.startPosY[j] + this.itemHeight;
                tween(t_node)
                    // 每列动画启动的时间
                    .delay(i * this.oneCircleTime)
                    .to(nodeMoveEndPosYTime, { position: v3(0, this.endPosY, 0) })
                    // 移动到底部看不见后，立即移动到顶部看不见的位置
                    .call(() => {
                        t_node.setPosition(v3(0, this.topPosY, 0));
                    })
                    .sequence(
                        tween(t_node).to(this.oneCircleTime, { position: v3(0, this.endPosY, 0) }),
                        tween(t_node).call(() => t_node.setPosition(v3(0, this.topPosY, 0)))
                    )
                    .repeat(2)
                    .to(endPosYTime, { position: v3(0, this.startPosY[j], 0) })
                    .call(() => {
                        if (this.row - 1 == i && this.line - 1 == j) {
                            log('动画结束')
                            this.isPlaying = false;
                        }
                    })
                    .start();
            }
        }
    }
}

let abs = Math.abs;

