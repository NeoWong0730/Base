﻿using System;
using UnityEngine;
using UnityEngine.UI;

public class RectTransformSize : MonoBehaviour {
    public float size = 200f;
    public ScrollRect scrollRect;
    
    public void Calc() {
        //RectTransform rt = transform as RectTransform;
        //rt.sizeDelta = RectTransformUtility.CalculateRelativeRectTransformBounds(rt).size;
    }
}
