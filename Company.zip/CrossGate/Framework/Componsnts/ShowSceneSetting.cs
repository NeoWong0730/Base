﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShowSceneSetting : MonoBehaviour
{
    public Vector2Int vResolution;
    public float fScale = 1.0f;
}
