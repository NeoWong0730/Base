﻿using UnityEngine;

namespace Logic
{
    public class ModelTager : MonoBehaviour
    {
        public Transform modelMesh;
        public Transform modelMeshAnimator;
    }
}
