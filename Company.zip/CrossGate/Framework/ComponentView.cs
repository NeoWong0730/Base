﻿using UnityEngine;

namespace Framework
{
    public class ComponentView : MonoBehaviour
    {
        public object Component { get; set; }
    }
}
