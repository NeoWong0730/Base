﻿using UnityEngine;

public abstract class ScopeDetection
{
    public abstract bool Contains(Transform trans);
}

