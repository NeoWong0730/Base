﻿public static class Tags
{
    public const string Untagged = "Untagged";
    public const string Respawn = "Respawn";
    public const string Finish = "Finish";
    public const string MainCamera = "MainCamera";    
    public const string Player = "Player";
    public const string GameController = "GameController";
    public const string UICamera = "UICamera";
    public const string ShowCamera = "3dCamera";
    public const string NightLight = "NightLight";
    public const string MainLight = "MainLight";
}
