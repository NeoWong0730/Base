﻿using System.Collections.Generic;
using UnityEngine;

namespace Framework
{
    public class AssetDependencies : MonoBehaviour
    {        
        public List<Object> mCustomDependencies;
    }
}
