using System;

public class TypeDrawerAttribute : Attribute
{
}