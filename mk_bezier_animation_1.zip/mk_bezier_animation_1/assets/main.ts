import * as cc from "cc";
import { RollingLottery, RollingLottery_ } from "./RollingLottery";
import { RotatingLottery, RotatingLottery_ } from "./RotatingLottery";
import { ScrollCell, ScrollCell_ } from "./ScrollCell";
const { ccclass, property } = cc._decorator;

@ccclass
// eslint-disable-next-line @typescript-eslint/naming-convention
export class main extends cc.Component {
	/** 横向滚动 */
	@property({ displayName: "横向滚动", type: RollingLottery })
	horizontalScroll: RollingLottery = null!;

	/** 竖向滚动 */
	@property({ displayName: "竖向滚动", type: RollingLottery })
	verticalScroll: RollingLottery = null!;

	/** 旋转转盘 */
	@property({ displayName: "旋转转盘", type: RotatingLottery })
	rotateTurntable: RotatingLottery = null!;

	/** 旋转指针 */
	@property({ displayName: "旋转指针", type: RotatingLottery })
	rotateArrow: RotatingLottery = null!;

	/** 滚动单格 */
	@property({ displayName: "滚动单格", type: ScrollCell })
	scrollCell: ScrollCell = null!;

	/* ------------------------------- segmentation ------------------------------- */
	async start() {
		const scrollF = async (): Promise<any> => {
			const targetIndexN = Math.floor(Math.random() * 100 - 50);

			cc.log("滚动目标", targetIndexN);
			const task = new Promise<void>((resolveF) => {
				this.horizontalScroll.move(targetIndexN, {
					tweenIndexNS: [0],
					endCBF: resolveF,
				});

				resolveF();
			});

			const task2 = new Promise<void>((resolveF) => {
				this.verticalScroll.move(targetIndexN, {
					tweenIndexNS: [0],
					endCBF: resolveF,
				});
			});

			await Promise.all([task, task2]);
			setTimeout(() => {
				scrollF();
			}, 1000);
		};

		const rotateF = async (): Promise<any> => {
			const targetIndexN = Math.floor(Math.random() * 12);

			cc.log("旋转目标", targetIndexN);
			const task = new Promise<void>((resolveF) => {
				this.rotateTurntable.move(targetIndexN, {
					tweenIndexNS: [0],
					endCBF: resolveF,
				});
			});

			const task2 = new Promise<void>((resolveF) => {
				this.rotateArrow.move(targetIndexN, {
					tweenIndexNS: [0],
					endCBF: resolveF,
				});
			});

			await Promise.all([task, task2]);
			setTimeout(() => {
				rotateF();
			}, 1000);
		};

		const scroll2F = async (): Promise<any> => {
			const targetIndexN = Math.floor(Math.random() * 8);

			cc.log("滚动单格目标", targetIndexN);
			const task = new Promise<void>((resolveF) => {
				this.scrollCell.move(targetIndexN, {
					tweenIndexNS: [0],
					endCBF: resolveF,
					turnN: 5,
				});
			});

			await Promise.all([task]);
			setTimeout(() => {
				scroll2F();
			}, 1000);
		};

		// 滚动 loop -> move 无缝切换
		// eslint-disable-next-line no-constant-condition
		if (false) {
			/** 假设一圈为 10 */
			const turnN = 10;
			const targetIndexN = 5;

			const config = new RollingLottery_.ScrollConfig({
				tweenIndexNS: [0],
			});

			await new Promise<void>((resolveF) => {
				this.verticalScroll.loop(300, { timeSN: 3, endCBF: resolveF });
			});

			await new Promise<void>((resolveF) => {
				const currentTargetIndexN = this.verticalScroll.currIndexN - (turnN + (this.verticalScroll.currIndexN % turnN)) - targetIndexN;
				const speedN = this.verticalScroll.getSpeed(currentTargetIndexN, config);

				this.verticalScroll.transition(speedN, 5, { endCBF: resolveF });
			});

			const currentTargetIndexN = this.verticalScroll.currIndexN - (turnN + (this.verticalScroll.currIndexN % turnN)) - targetIndexN;

			await new Promise<void>((resolveF) => {
				this.verticalScroll.move(currentTargetIndexN, {
					...config,
					endCBF: resolveF,
				});
			});
		} else {
			scrollF();
		}

		// 转盘 loop -> move 无缝切换
		// eslint-disable-next-line no-constant-condition
		if (false) {
			const targetIndexN = 5;

			const config = new RotatingLottery_.ScrollConfig({
				tweenIndexNS: [0],
				turnN: 1,
			});

			await new Promise<void>((resolveF) => {
				this.rotateTurntable.loop(100, { timeSN: 3, endCBF: resolveF });
			});

			await new Promise<void>((resolveF) => {
				const speedN = this.rotateTurntable.getSpeed(targetIndexN, config);

				this.rotateTurntable.transition(speedN, 5, { endCBF: resolveF });
			});

			await new Promise<void>((resolveF) => {
				this.rotateTurntable.move(targetIndexN, {
					...config,
					endCBF: resolveF,
				});
			});
		} else {
			rotateF();
		}

		// 滚动单格 loop -> move 无缝切换
		// eslint-disable-next-line no-constant-condition
		if (false) {
			const targetIndexN = 5;

			const config = new ScrollCell_.ScrollConfig({
				tweenIndexNS: [0],
				turnN: 3,
			});

			await new Promise<void>((resolveF) => {
				this.scrollCell.loop(0.5, { timeSN: 3, endCBF: resolveF });
			});

			await new Promise<void>((resolveF) => {
				const speedN = this.scrollCell.getSpeed(targetIndexN, config);

				this.scrollCell.transition(speedN, 5, { endCBF: resolveF });
			});

			await new Promise<void>((resolveF) => {
				this.scrollCell.move(targetIndexN, {
					...config,
					endCBF: resolveF,
				});
			});
		} else {
			scroll2F();
		}
	}

	/* ------------------------------- segmentation ------------------------------- */
	eventItemUpdate(node_: cc.Node, indexN_: number): void {
		node_.getComponentInChildren(cc.Label)!.string = indexN_ + "";
	}

	eventCeilUpdate(currIndexN_: number, preIndexN_: number, jumpB_: boolean): void {
		const lenN = this.scrollCell.contentNode.children.length;

		if (currIndexN_ < 0) {
			currIndexN_ = lenN - Math.abs(Math.floor(currIndexN_ % lenN));
		}

		if (preIndexN_ !== undefined && preIndexN_ < 0) {
			preIndexN_ = lenN - Math.abs(Math.floor(preIndexN_ % lenN));
		}

		currIndexN_ = currIndexN_ % lenN;

		// cc.log("单格当前下标", currIndexN_);
		// 更新上个选中节点
		if (preIndexN_ !== undefined) {
			preIndexN_ = preIndexN_ % lenN;
			this.scrollCell.contentNode.children[preIndexN_].getComponent(cc.Sprite)!.color = cc.Color.WHITE;
		}

		// 更新当前选中节点
		this.scrollCell.contentNode.children[currIndexN_].getComponent(cc.Sprite)!.color = cc.Color.RED;
	}

	eventCenterNode(indexN_: number): void {
		cc.log("当前下标", indexN_);
	}

	eventScrollEnd(): void {
		// cc.log('滚动结束');
	}
}
