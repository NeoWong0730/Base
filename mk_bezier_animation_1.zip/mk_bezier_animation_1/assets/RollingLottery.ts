import * as cc from "cc";
import { MoveBase, MoveBase_ } from "./MoveBase";
const { ccclass, property, requireComponent } = cc._decorator;

namespace _RollingLottery {
	/** 方向 */
	export enum Direction {
		竖,
		横,
	}
}

/** 滚动抽奖 */
@ccclass
export class RollingLottery extends MoveBase {
	/* --------------- 属性 --------------- */
	/** 子节点刷新事件 */
	@property({
		displayName: "子节点刷新事件",
		tooltip: "(子节点_node, 下标_indexN)",
		type: cc.EventHandler,
	})
	itemUpdateEvent = new cc.EventHandler();

	/** 方向 */
	@property({
		displayName: "方向",
		type: cc.Enum(_RollingLottery.Direction),
	})
	dire = _RollingLottery.Direction.竖;

	/* --------------- private --------------- */
	/** 周长 */
	private _perimeterN = 0;
	/** 子节点大小 */
	private _itemSize!: cc.Size;
	/** 自己矩形 */
	private _selfRect = cc.rect();
	/** 父节点中心点矩形 */
	private _parentCenterRect!: cc.Rect;
	/** uiTransform 表 */
	private _uiTransformTab!: Record<string, cc.UITransform | null>;
	/* --------------- 临时变量 --------------- */
	private _tempTab = {
		valueM4: cc.mat4(),
		value2M4: cc.mat4(),
		valueRect: cc.rect(),
	};

	/** 滚动子节点临时变量 */
	private _temp = new (class {
		/** 当前节点矩形 */
		currNodeRect = cc.rect();
		/** 更新节点坐标 */
		updatePosB = false;
		/** 当前节点 UITransform */
		currTransform!: cc.UITransform;
		/** 当前下标 */
		currIndexN!: number;
		/** 超出周长倍数 */
		outOfRangeMultipleN!: number;
	})();

	/* ------------------------------- 生命周期 ------------------------------- */
	onLoad() {
		super.onLoad();
		this._initView();
		this._initEvent();
	}

	/* ------------------------------- 功能 ------------------------------- */
	/** 初始化事件 */
	private _initEvent(): void {
		this.node.on(cc.Node.EventType.CHILD_ADDED, this._nodeChildAdded, this);
		this.node.on(cc.Node.EventType.CHILD_REMOVED, this._nodeChildRemoved, this);
	}

	/** 初始化视图 */
	private _initView(): void {
		const layout = this.node.getComponent(cc.Layout);

		if (layout) {
			layout.enabled = false;
		}

		// 初始化子节点及选中
		if (this.node.children.length) {
			// 重置子节点
			this.node.children.forEach((v, kN) => {
				v.name = String(kN + this._currIndexN);
				this.itemUpdateEvent.emit([v, kN + this._currIndexN]);
			});

			this.jump(this._currIndexN);
		}
	}

	/** 重制数据 */
	private _resetData(): void {
		this._currIndexN = 0;
		this._itemSize = this.node.children[0].getComponent(cc.UITransform)!.contentSize.clone();

		// item 大小矩形，中心点在节点 (0, 0) 位置
		this._parentCenterRect = cc.rect(-this._itemSize.width * 0.5, -this._itemSize.height * 0.5, this._itemSize.width, this._itemSize.height);

		// 重置数据
		this._uiTransformTab = Object.create(null);
		this._uiTransformTab[this.node.parent!.uuid] = this.node.getComponent(cc.UITransform);
		this._uiTransformTab[this.node.uuid] = this.node.getComponent(cc.UITransform);
		this._selfRect = this._getBoundingBoxToWorld(this.node);
		this._perimeterN = 0;

		// 更新周长
		let itemSize: cc.Size;

		this.node.children.forEach((v) => {
			this._uiTransformTab[v.uuid] = v.getComponent(cc.UITransform);
			itemSize = this._uiTransformTab[v.uuid]!.contentSize;
			this._perimeterN += this.dire === _RollingLottery.Direction.横 ? itemSize.width : itemSize.height;
		});
	}

	/** 重制视图 */
	private _resetView(): void {
		const layout = this.node.getComponent(cc.Layout);

		if (layout) {
			layout.enabled = false;
		}

		// 重置坐标
		{
			const startPosV3 = this.node.position.clone();

			if (this.dire === _RollingLottery.Direction.横) {
				this.node.children.forEach((v, kN) => {
					v.position = cc.v3(startPosV3.x + this._parentCenterRect.width * kN, this.node.position.y);
				});
			} else {
				this.node.children.forEach((v, kN) => {
					v.position = cc.v3(this.node.position.x, startPosV3.y - this._parentCenterRect.height * kN);
				});
			}
		}

		// 初始化子节点及选中
		if (this.node.children.length) {
			// 重置子节点
			this.node.children.forEach((v, kN) => {
				v.name = String(kN + this._currIndexN);
				this.itemUpdateEvent.emit([v, kN + this._currIndexN]);
			});

			this.jump(this._currIndexN);
		}
	}

	/** 重置 */
	private _reset(): void {
		if (!this.node.children.length) {
			return;
		}

		this._resetData();
		this._resetView();
	}

	/**
	 * 获取在世界坐标系下的节点包围盒(不包含自身激活的子节点范围)
	 * @param node_ 目标节点
	 * @param outRect_ 输出矩形
	 * @returns 输出矩形
	 */
	private _getBoundingBoxToWorld(node_: cc.Node, outRect_ = cc.rect()): cc.Rect {
		const uiTransform = this._uiTransformTab[node_.uuid]!;

		cc.Mat4.fromRTS(this._tempTab.valueM4, node_.getRotation(), node_.getPosition(), node_.getScale());
		const width = uiTransform.contentSize.width;
		const height = uiTransform.contentSize.height;

		outRect_.set(-uiTransform.anchorPoint.x * width, -uiTransform.anchorPoint.y * height, width, height);

		// node_.parent!.getWorldMatrix(this._tempTab.value2M4);
		// cc.Mat4.multiply(this._tempTab.value2M4, this._tempTab.value2M4, this._tempTab.valueM4);
		// outRect_.transformMat4(this._tempTab.value2M4);
		outRect_.transformMat4(this._tempTab.valueM4);

		return outRect_;
	}

	/**
	 * 更新节点下标
	 * @param node_ 目标节点
	 * @param indexN_ 下标
	 */
	private _updateNodeIndex(node_: cc.Node, indexN_: number): void {
		node_.name = String(indexN_);
		this.itemUpdateEvent.emit([node_, indexN_]);
	}

	/**
	 * 上到下移动子节点
	 * @param distN_ 距离
	 */
	private _moveNodeTopToBottom(distN_: number): void {
		this.node.children.forEach((v, kN) => {
			this._temp.currTransform = this._uiTransformTab[v.uuid]!;
			this._temp.updatePosB = false;
			this._getBoundingBoxToWorld(v, this._temp.currNodeRect);

			// 移动坐标
			this._temp.currNodeRect.y += distN_;

			// 相交则更新节点坐标
			if (this._temp.currNodeRect.intersects(this._selfRect)) {
				this._temp.updatePosB = true;
			}
			// 若不相交则超出范围
			else {
				// 若节点在上方则跳过更新
				if (this._temp.currNodeRect.yMin > this._selfRect.yMax) {
					this._temp.updatePosB = true;
				} else {
					// (超出范围 / 周长) + 超出视图区域的 1
					this._temp.outOfRangeMultipleN = Math.floor((this._selfRect.yMin - this._temp.currNodeRect.yMax) / this._perimeterN) + 1;

					// 更新坐标
					this._temp.currNodeRect.y += this._temp.outOfRangeMultipleN * this._perimeterN;
					v.position = cc.v3(v.position.x, this._temp.currNodeRect.y + this._itemSize.height * this._temp.currTransform.anchorY);

					// 更新 item 下标
					this._updateNodeIndex(v, Number(v.name) - this._temp.outOfRangeMultipleN * this.node.children.length);
				}
			}

			// 更新节点坐标
			if (this._temp.updatePosB) {
				v.position = cc.v3(v.position.x, this._temp.currNodeRect.y + this._temp.currNodeRect.height * this._temp.currTransform.anchorY);
			}

			// 更新当前下标
			this._temp.currIndexN = Number(v.name);

			if (
				this._temp.currIndexN < this._currIndexN &&
				cc.Rect.intersection(this._tempTab.valueRect, this._temp.currNodeRect, this._parentCenterRect).height >=
					this._parentCenterRect.height * 0.5
			) {
				this.currIndexN = this._temp.currIndexN;
			}
		});
	}

	/**
	 * 下到上移动子节点
	 * @param distN_ 距离
	 */
	private _moveNodeBottomToTop(distN_: number): void {
		this.node.children.forEach((v, kN) => {
			this._temp.currTransform = this._uiTransformTab[v.uuid]!;
			this._temp.updatePosB = false;
			this._getBoundingBoxToWorld(v, this._temp.currNodeRect);

			// 移动坐标
			this._temp.currNodeRect.y += distN_;

			// 相交则更新节点坐标
			if (this._temp.currNodeRect.intersects(this._selfRect)) {
				this._temp.updatePosB = true;
			}
			// 若不相交则超出范围
			else {
				// 若节点在下方则跳过更新
				if (this._selfRect.yMin > this._temp.currNodeRect.yMax) {
					this._temp.updatePosB = true;
				} else {
					// (超出范围 / 周长) + 超出视图区域的 1
					this._temp.outOfRangeMultipleN = Math.floor((this._temp.currNodeRect.yMin - this._selfRect.yMax) / this._perimeterN) + 1;

					// 更新坐标
					this._temp.currNodeRect.y -= this._temp.outOfRangeMultipleN * this._perimeterN;
					v.position = cc.v3(v.position.x, this._temp.currNodeRect.y + this._itemSize.height * this._temp.currTransform.anchorY);

					// 更新 item 下标
					this._updateNodeIndex(v, Number(v.name) + this._temp.outOfRangeMultipleN * this.node.children.length);
				}
			}

			// 更新节点坐标
			if (this._temp.updatePosB) {
				v.position = cc.v3(v.position.x, this._temp.currNodeRect.y + this._temp.currNodeRect.height * this._temp.currTransform.anchorY);
			}

			// 更新当前下标
			this._temp.currIndexN = Number(v.name);
			if (
				this._temp.currIndexN > this._currIndexN &&
				cc.Rect.intersection(this._tempTab.valueRect, this._temp.currNodeRect, this._parentCenterRect).height >=
					this._parentCenterRect.height * 0.5
			) {
				this.currIndexN = this._temp.currIndexN;
			}
		});
	}

	/**
	 * 左到右移动子节
	 * @param distN_ 距离
	 */
	private _moveNodeLeftToRight(distN_: number): void {
		this.node.children.forEach((v, kN) => {
			this._temp.currTransform = this._uiTransformTab[v.uuid]!;
			this._temp.updatePosB = false;
			this._getBoundingBoxToWorld(v, this._temp.currNodeRect);

			// 移动坐标
			this._temp.currNodeRect.x += distN_;

			// 相交则更新节点坐标
			if (this._temp.currNodeRect.intersects(this._selfRect)) {
				this._temp.updatePosB = true;
			}
			// 若不相交则超出范围
			else {
				// 若节点在左方则跳过更新
				if (this._temp.currNodeRect.xMax < this._selfRect.xMin) {
					this._temp.updatePosB = true;
				} else {
					// (超出范围 / 周长) + 超出视图区域的 1
					this._temp.outOfRangeMultipleN = Math.floor((this._temp.currNodeRect.xMin - this._selfRect.xMax) / this._perimeterN) + 1;

					// 更新坐标
					this._temp.currNodeRect.x -= this._temp.outOfRangeMultipleN * this._perimeterN;
					v.position = cc.v3(this._temp.currNodeRect.x + this._itemSize.width * this._temp.currTransform.anchorX, v.position.y);

					// 更新 item 下标
					this._updateNodeIndex(v, Number(v.name) - this._temp.outOfRangeMultipleN * this.node.children.length);
				}
			}

			// 更新节点坐标
			if (this._temp.updatePosB) {
				v.position = cc.v3(this._temp.currNodeRect.x + this._temp.currNodeRect.width * this._temp.currTransform.anchorX, v.position.y);
			}

			// 更新当前下标
			this._temp.currIndexN = Number(v.name);

			if (
				this._temp.currIndexN < this._currIndexN &&
				cc.Rect.intersection(this._tempTab.valueRect, this._temp.currNodeRect, this._parentCenterRect).width >=
					this._parentCenterRect.width * 0.5
			) {
				this.currIndexN = this._temp.currIndexN;
			}
		});
	}

	/**
	 * 右到左移动子节
	 * @param distN_ 距离
	 */
	private _moveNodeRightToLeft(distN_: number): void {
		this.node.children.forEach((v, kN) => {
			this._temp.currTransform = this._uiTransformTab[v.uuid]!;
			this._temp.updatePosB = false;
			this._getBoundingBoxToWorld(v, this._temp.currNodeRect);

			// 移动坐标
			this._temp.currNodeRect.x += distN_;

			// 相交则更新节点坐标
			if (this._temp.currNodeRect.intersects(this._selfRect)) {
				this._temp.updatePosB = true;
			}
			// 若不相交则超出范围
			else {
				// 若节点在右方则跳过更新
				if (this._temp.currNodeRect.xMin > this._selfRect.xMax) {
					this._temp.updatePosB = true;
				} else {
					// (超出范围 / 周长) + 超出视图区域的 1
					this._temp.outOfRangeMultipleN = Math.floor((this._selfRect.xMin - this._temp.currNodeRect.xMax) / this._perimeterN) + 1;

					// 更新坐标
					this._temp.currNodeRect.x += this._temp.outOfRangeMultipleN * this._perimeterN;
					v.position = cc.v3(this._temp.currNodeRect.x + this._itemSize.width * this._temp.currTransform.anchorX, v.position.y);

					// 更新 item 下标
					this._updateNodeIndex(v, Number(v.name) + this._temp.outOfRangeMultipleN * this.node.children.length);
				}
			}

			// 更新节点坐标
			if (this._temp.updatePosB) {
				v.position = cc.v3(this._temp.currNodeRect.x + this._temp.currNodeRect.width * this._temp.currTransform.anchorX, v.position.y);
			}

			// 更新当前下标
			this._temp.currIndexN = Number(v.name);

			if (
				this._temp.currIndexN > this._currIndexN &&
				cc.Rect.intersection(this._tempTab.valueRect, this._temp.currNodeRect, this._parentCenterRect).width >=
					this._parentCenterRect.width * 0.5
			) {
				this.currIndexN = this._temp.currIndexN;
			}
		});
	}

	/** 初始化数据 */
	protected _initData(): void {
		super._initData();
		this._resetData();
	}

	/** 运动 */
	protected _move(valueN_: number): void {
		if (!valueN_) {
			return;
		}

		// 左右滚动
		if (this.dire === _RollingLottery.Direction.横) {
			// 从左往右
			if (valueN_ > 0) {
				this._moveNodeLeftToRight(valueN_);
			}
			// 从右往左
			else if (valueN_ < 0) {
				this._moveNodeRightToLeft(valueN_);
			}
		}
		// 上下滚动
		else {
			// 从上往下
			if (valueN_ < 0) {
				this._moveNodeTopToBottom(valueN_);
			}
			// 从下往上
			else if (valueN_ > 0) {
				this._moveNodeBottomToTop(valueN_);
			}
		}
	}

	/** 获取当前下标 */
	protected _getCurrIndex(): number {
		return this.currIndexN;
	}

	protected _getMoveDist(indexN_: number, scrollConfig_?: RollingLottery_.ScrollConfig): number {
		/** 当前节点 */
		const currNode = this.node.getChildByName(String(this._currIndexN))!;
		/** 间隔格子 */
		const intervalN = indexN_ - this._currIndexN;
		/** 格子距离 */
		const boxDistN = this.dire === _RollingLottery.Direction.横 ? this._itemSize.width : this._itemSize.height;

		/** 当前格子距父节点(0, 0)的偏移坐标 */
		const offsetDistV3 = this.node.position
			.clone()
			.subtract(this._uiTransformTab[this.node.parent!.uuid]!.convertToNodeSpaceAR(currNode.worldPosition)!);

		// 设置总距离
		if (this.dire === _RollingLottery.Direction.横) {
			return -intervalN * boxDistN + offsetDistV3.x;
		} else {
			return intervalN * boxDistN + offsetDistV3.y;
		}
	}

	loop(speedN_: number, config_?: MoveBase_.LoopConfig): void {
		if (this.dire === _RollingLottery.Direction.竖) {
			speedN_ = -speedN_;
		}

		super.loop(speedN_, config_);
	}

	move(indexN_: number, scrollConfig_?: RollingLottery_.ScrollConfig): void {
		super.move(indexN_, new RollingLottery_.ScrollConfig(scrollConfig_));
	}

	jump(indexN_: number): void {
		super.jump(indexN_);
		this.currIndexN = indexN_;
	}

	getSpeed(indexN_: number, config_?: RollingLottery_.ScrollConfig): number {
		return super.getSpeed(indexN_, new RollingLottery_.ScrollConfig(config_));
	}

	/* ------------------------------- 节点事件 ------------------------------- */
	private _nodeChildAdded(): void {
		this.unschedule(this._reset);
		this.scheduleOnce(this._reset);
	}

	private _nodeChildRemoved(): void {
		this.unschedule(this._reset);
		this.scheduleOnce(this._reset);
	}
}

export namespace RollingLottery_ {
	/** 方向 */
	// eslint-disable-next-line @typescript-eslint/naming-convention
	export const Direction = _RollingLottery.Direction;
	/** 方向 */
	export type Direction = _RollingLottery.Direction;

	/** 滚动配置 */
	export class ScrollConfig extends MoveBase_.MoveConfig {
		constructor(init_?: ScrollConfig) {
			super(init_);
		}
	}
}
