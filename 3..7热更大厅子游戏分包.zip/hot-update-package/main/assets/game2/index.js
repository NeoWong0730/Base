System.register("chunks:///_virtual/game2",["./Game2.ts"],(function(){"use strict";return{setters:[null],execute:function(){}}}));

System.register("chunks:///_virtual/Game2.ts",["cc"],(function(e){"use strict";var t,a,s,c,o,n;return{setters:[function(e){t=e.cclegacy,a=e.Component,s=e.director,c=e.native,o=e.assetManager,n=e._decorator}],execute:function(){var l;t._RF.push({},"ad2df9ihepIyqgvmjsc+lKL","Game2",void 0);const{ccclass:r,property:m}=n;e("Game2",r("Game2")(l=class extends a{start(){}update(e){}onBack(){s.loadScene("Hall",null,(()=>{console.log("==================game2=======back");let e=c.fileUtils.getWritablePath()+"game-remote-asset/game2/assets/game2",t=o.getBundle(e);t&&(console.log("==================remove game2 bundle=======back"),o.removeBundle(t))}))}})||l);t._RF.pop()}}}));

(function(r) {
  r('virtual:///prerequisite-imports/game2', 'chunks:///_virtual/game2'); 
})(function(mid, cid) {
    System.register(mid, [cid], function (_export, _context) {
    return {
        setters: [function(_m) {
            var _exportObj = {};

            for (var _key in _m) {
              if (_key !== "default" && _key !== "__esModule") _exportObj[_key] = _m[_key];
            }
      
            _export(_exportObj);
        }],
        execute: function () { }
    };
    });
});