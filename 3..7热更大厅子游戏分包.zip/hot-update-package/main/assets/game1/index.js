System.register("chunks:///_virtual/game1",["./Game1.ts"],(function(){"use strict";return{setters:[null],execute:function(){}}}));

System.register("chunks:///_virtual/Game1.ts",["cc"],(function(e){"use strict";var t,a,c,n,r;return{setters:[function(e){t=e.cclegacy,a=e.Component,c=e.director,n=e.assetManager,r=e._decorator}],execute:function(){var s;t._RF.push({},"02b31jw5qZINZEVUe226O0R","Game1",void 0);const{ccclass:o,property:u}=r;e("Game1",o("Game1")(s=class extends a{start(){}update(e){}onBack(){c.loadScene("Hall",null,(()=>{let e=n.getBundle("game1");e&&n.removeBundle(e)}))}})||s);t._RF.pop()}}}));

(function(r) {
  r('virtual:///prerequisite-imports/game1', 'chunks:///_virtual/game1'); 
})(function(mid, cid) {
    System.register(mid, [cid], function (_export, _context) {
    return {
        setters: [function(_m) {
            var _exportObj = {};

            for (var _key in _m) {
              if (_key !== "default" && _key !== "__esModule") _exportObj[_key] = _m[_key];
            }
      
            _export(_exportObj);
        }],
        execute: function () { }
    };
    });
});