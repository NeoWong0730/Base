System.register(["./instantiated-f1a5e527.js"],(function(t){"use strict";return{setters:[function(e){t("default",e.gZ)}],execute:function(){}}}));
