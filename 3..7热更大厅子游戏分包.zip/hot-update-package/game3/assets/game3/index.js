System.register("chunks:///_virtual/game3",["./Game3.ts"],(function(){"use strict";return{setters:[null],execute:function(){}}}));

System.register("chunks:///_virtual/Game3.ts",["cc"],(function(e){"use strict";var t,a,s,c,r,n;return{setters:[function(e){t=e.cclegacy,a=e.Component,s=e.director,c=e.native,r=e.assetManager,n=e._decorator}],execute:function(){var l;t._RF.push({},"86011x8/TBOmqdD4osMlsPx","Game3",void 0);const{ccclass:o,property:i}=n;e("Game3",o("Game3")(l=class extends a{start(){}update(e){}onClickBack(){s.loadScene("Hall",null,(()=>{let e=c.fileUtils.getWritablePath()+"game-remote-asset/game3/assets/game3",t=r.getBundle(e);t&&r.removeBundle(t)}))}})||l);t._RF.pop()}}}));

(function(r) {
  r('virtual:///prerequisite-imports/game3', 'chunks:///_virtual/game3'); 
})(function(mid, cid) {
    System.register(mid, [cid], function (_export, _context) {
    return {
        setters: [function(_m) {
            var _exportObj = {};

            for (var _key in _m) {
              if (_key !== "default" && _key !== "__esModule") _exportObj[_key] = _m[_key];
            }
      
            _export(_exportObj);
        }],
        execute: function () { }
    };
    });
});