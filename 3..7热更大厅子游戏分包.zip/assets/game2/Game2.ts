import { _decorator, assetManager, Component, director, native, Node } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('Game2')
export class Game2 extends Component {
    start() {

    }

    update(deltaTime: number) {
    }

    onBack() {
        director.loadScene("Hall", null, () => {
            // remove bundle
            let name = native.fileUtils.getWritablePath() + "game-remote-asset/game2/assets/game2";
            let bundle = assetManager.getBundle(name)
            if (bundle) {
                assetManager.removeBundle(bundle)
            }
        })
    }
}
