import { _decorator, Component, director, game, Node } from 'cc';
import { JSB, NATIVE } from 'cc/env';
import { HotUpdateCtrl } from './hotupdate/HotUpdateCtrl';
import { GameConst } from './config/GameConst';
import { HotUpdateEvent } from './hotupdate/HotUpdateEvent';
const { ccclass, property } = _decorator;

@ccclass('NewComponent')
export class NewComponent extends Component {
    hotupdateCtrl: HotUpdateCtrl = null
    async start() {
        if (!NATIVE || !JSB) {
            this._enterHall()
            return
        }

        director.on(HotUpdateEvent.HotUpdateRate, this.onHotUpdateRate, this);
        director.on(HotUpdateEvent.HotUpdateFinish, this.onHotUpdateFinish, this);
        director.on(HotUpdateEvent.CheckVersionResult, this.onCheckVersionResult, this);

        this.hotupdateCtrl = new HotUpdateCtrl()
        let packageUrl = `${GameConst.serverip}/main/`
        await this.hotupdateCtrl.init("main", packageUrl)
        this.hotupdateCtrl.checkUpdate()
    }

    /**
     * 热更新版本检查结果
     */
    onCheckVersionResult(name: string, newVersionFoud: boolean) {
        console.log(`CheckVersionResult: ${name}, ${newVersionFoud}`)
        if (newVersionFoud) {
            this.hotupdateCtrl && this.hotupdateCtrl.hotUpdate();
        } else {
            this._enterHall();
        }
    }

    /**
     * 热更进度回调
     */
    onHotUpdateRate(name: string, rate: number) {
    }

    /**
     * 更新完成
     */
    onHotUpdateFinish(name: string, success: boolean) {
        if (success) {
            console.log("========onHotUpdateFinish======", name)
            setTimeout(() => {
                game.restart()
            }, 500)
        } else {  // 热更失败
            this._enterHall()
        }
    }

    update(deltaTime: number) {
    }

    private _enterHall() {
        director.loadScene("Hall")
    }

    protected onDestroy(): void {
        director.targetOff(this)
        this.hotupdateCtrl && this.hotupdateCtrl.destory()
    }
}
