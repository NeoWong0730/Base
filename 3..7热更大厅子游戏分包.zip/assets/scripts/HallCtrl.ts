import { _decorator, AssetManager, assetManager, Component, director, Node, SceneAsset } from 'cc';
import { HotUpdateEvent } from './hotupdate/HotUpdateEvent';
import { HotUpdateCtrl } from './hotupdate/HotUpdateCtrl';
import { GameConst } from './config/GameConst';
import { JSB, NATIVE } from 'cc/env';
import { Label } from 'cc';
import { native } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('HallCtrl')
export class HallCtrl extends Component {
    subGameHotUpdateCtrls: { [key: string]: HotUpdateCtrl } = {};
    loadingSubGame: string = "";

    @property(Label)
    remoteAssets: Label

    start() {
        if (NATIVE) {
            this.remoteAssets.string = native.fileUtils.getWritablePath() + "game-remote-asset/"
        } else {
            this.remoteAssets.string = "Hello"
        }
    }

    protected onEnable(): void {
        director.on(HotUpdateEvent.HotUpdateRate, this.onHotUpdateRate, this)
        director.on(HotUpdateEvent.HotUpdateFinish, this.onHotUpdateFinish, this)
        director.on(HotUpdateEvent.CheckVersionResult, this.onCheckVersionResult, this)
    }
    update(deltaTime: number) {
    }

    onEnterGame1() {
        assetManager.loadBundle("game1", (err, bundle: AssetManager.Bundle) => {
            if (err) {
                console.log(err)
                return
                // throw err;
            }
            bundle.loadScene("game1", (err, sceneAsset: SceneAsset) => {
                if (err) {
                    console.log(err)
                    return;
                }
                director.runScene(sceneAsset, null, () => {
                    console.log(`enter game1 success`);
                });
            });
        })
    }

    onEnterGame2() {
        this._loadGame("game2");
    }

    onEnterGame3() {
        this._loadGame("game3")
    }
    /**
     * 热更新版本检查结果
     */
    async onCheckVersionResult(subGameName: string, newVersionFoud: boolean) {
       // this.loadingSubGame = "";
       console.log('-------CheckVersionResult-------', subGameName, newVersionFoud)
        if (newVersionFoud) {
            // this.hotupdateCtrl && this.hotupdateCtrl.hotUpdate();
            let ctrl = await this.getSubGameHotUpdateCtrl(subGameName)
            ctrl.hotUpdate()
        } else {
            this._enterGame(subGameName)
          //  this.subGameHotUpdateCtrls[subGameName] = null
        }
    }

    /**
     * 热更进度回调
     */
    onHotUpdateRate(subGameName: string, rate: number) {
    }

    /**
     * 更新完成
     */
    onHotUpdateFinish(subGameName: string, success: boolean) {
        this._enterGame(subGameName);
    }

    async getSubGameHotUpdateCtrl(subGameName: string) {
        let ctrl = this.subGameHotUpdateCtrls[subGameName];
        if (!ctrl) {
            ctrl = new HotUpdateCtrl();
            let packageUrl = `${GameConst.serverip}/${subGameName}/`
            await ctrl.init(subGameName, packageUrl)
        }
        return ctrl
    }

    private async _loadGame(subGameName: string) {
        if (!NATIVE || !JSB) {
            return
        }
        this.loadingSubGame = subGameName

        let ctrl = await this.getSubGameHotUpdateCtrl(subGameName)
        ctrl.checkUpdate();
    }

    private async _enterGame(subGameName: string) {
        let ctrl = await this.getSubGameHotUpdateCtrl(subGameName)
        console.log('-------StorePath-------', ctrl.getStorePath())
         assetManager.loadBundle(ctrl.getStorePath() + `/assets/${subGameName}`, (err, bundle: AssetManager.Bundle) => {
             if (err) {
                 console.log(err)
                 return
                 // throw err;
             }
             bundle.loadScene(subGameName, (err, sceneAsset: SceneAsset) => {
                 if (err) {
                     console.log(err)
                     return
                 }
                 director.runScene(sceneAsset, null, () => {
                     console.log(`enter ${subGameName} success`)
                 })
             })
         })
     }

    protected onDisable(): void {
        director.targetOff(this)
    }
}
