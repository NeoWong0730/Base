/**
 * 热更事件
 */
export enum HotUpdateEvent {
    // 版本检查
    CheckVersionResult = "CheckVersionResult",
    // 更新进度
    HotUpdateRate = "HotUpdateRate",
    // 更新完成
    HotUpdateFinish = "HotUpdateFinish"
}
