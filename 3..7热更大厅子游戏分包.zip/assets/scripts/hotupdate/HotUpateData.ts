
export class HotUpateData {
    name: string;
    packageurl: string;
}
