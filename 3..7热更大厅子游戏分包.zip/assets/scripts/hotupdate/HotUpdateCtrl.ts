import { Asset, director, native, resources, sys } from 'cc';
import { DEBUG, JSB, NATIVE } from 'cc/env';
import { HotUpdateEvent } from './HotUpdateEvent';
import { game } from 'cc';
import { HotUpateData } from './HotUpateData';

export class HotUpdateCtrl {
    _name: string = "";
    /**
     * 更新中
     */
    _updating: boolean = false;

    /** 
     * 是否可以重试
     */
    _canRetry: boolean = false;

    /** 
     * 热更新存储路径
     */
    _storagePath: string = "";

    /**
     * 热更资源管理器
     */
    _am: native.AssetsManager = null;

    /**
     * 更新失败数量
     */
    _failCount: number = 0;

    /**
     * 版本信息
     */
    manifest: HotUpateData = null;

    log(...arg: string[]) {
        DEBUG && console.log("[HotUpdate]", ...arg);
    }

    inited: boolean = false;
    packageUrl: string = "";
    
    async isSettSearchPaths() {
        if (!NATIVE) {
            return false;
        }

        let hotUpdateSearchPaths = sys.localStorage.getItem("HotUpdateSearchPaths");
        if (!hotUpdateSearchPaths) {
            let storeagePath = native.fileUtils.getWritablePath() + "game-remote-asset/";
            let searchPath = storeagePath + "assets/"
            native.fileUtils.createDirectory(storeagePath);
            native.fileUtils.createDirectory(searchPath);
            try {
                let searchPaths = [searchPath];
                let newPaths = this._am.getLocalManifest().getSearchPaths();
                for (let i = 0; i < newPaths.length; i++) {
                    if (searchPaths.indexOf(newPaths[i]) == -1) {
                        Array.prototype.unshift.apply(searchPaths, [newPaths[i]]);
                    }
                }
                sys.localStorage.setItem("HotUpdateSearchPaths", JSON.stringify(searchPaths));
                native.fileUtils.setSearchPaths(searchPaths);
                return true;
            } catch (error) {
                return false;
            }
        }
        return false;
    }
    
    /**
     * 初始化
     */
    async init(name: string, packageUrl: string) {
        if (!NATIVE || !JSB) {
            return;
        }

        if (this.inited) {
            return;
        }

        let bSetSearch = await this.isSettSearchPaths();
        if (bSetSearch) {
            game.restart();
            return
        }

        this.packageUrl = packageUrl;
        this._name = name;
        this._storagePath = native.fileUtils.getWritablePath() + "game-remote-asset/" + this._name;

        try {
            this.manifest = await this.loadManifest();
        } catch (error) {
            console.error(error);
            throw error;
        }

        let versionCompareHandle = (localVersionName: string, remoteVersionName: string) => {
            let vA = localVersionName.split(".");
            let vB = remoteVersionName.split(".");
            for (let i = 0; i < vA.length; ++i) {
                let a = parseInt(vA[i]);
                let b = parseInt(vB[i] || "0");
                if (a === b) {
                    continue;
                } else {
                    return a - b;
                }
            }
            if (vB.length > vA.length) {
                return -1;
            } else {
                return 0;
            }
        };

        this._am = new native.AssetsManager(this.manifest.packageurl, this._storagePath, versionCompareHandle);
        this._am.setVerifyCallback((path: string, asset: native.ManifestAsset) => {
            let compressed = asset.compressed;
            // 检索正确的md5值。
            let expectedMD5 = asset.md5;
            // asset.path 为相对路径，path为绝对路径。
            let relativePath = asset.path;
            // 资源文件的大小，但这个值可能不存在。
            if (compressed) {
                this.log(`hotupdate verify ${relativePath}`);
                return true;
             } else {
                this.log(`hotupdate verify ${relativePath} ${expectedMD5}`);
                return true;
             }
        });

        this._am.setMaxConcurrentTask(2);
        this.log("-----------current version-----------", this._name, this._am.getLocalManifest().getVersion());
        this.inited = true;
    }

    /**
     * 检查更新
     */
    checkUpdate() {
        if (this._updating) {
            console.log("already check updating")
            return;
        }

        if (!this._am.getLocalManifest() || !this._am.getLocalManifest().isLoaded()) {
            this.emit(HotUpdateEvent.CheckVersionResult, false);
            return;
        }

        this._updating = true;
        this._am.setEventCallback(this.checkCallback.bind(this));
        this._am.checkUpdate();
    }

    /**
     * 发现新版本后，调用此方法进行热更新
     */
    hotUpdate() {
        if (this._am && !this._updating) {
            this._am.setEventCallback(this.updateCallback.bind(this));
            if (this._am.getState() === native.AssetsManager.State.UNINITED) {
                let url = this.manifest.packageurl;
                this._am.loadLocalManifest(url);
            }
            this._failCount = 0;
            this._updating = true;
            this._am.update();
        }
    }

    /**
     * 版本检查回调
     */
    checkCallback(event: native.EventAssetsManager) {
        let newVersionFoud = null;
        switch (event.getEventCode()) {
            case native.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
                this.log(`checkout hotupdate code: ${event.getEventCode()} no local Manifest`);
                newVersionFoud = false;
                break;
            case native.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
                this.log(`checkout hotupdate code: ${event.getEventCode()} download Manifest failed`);
                newVersionFoud = false;
                break;
            case native.EventAssetsManager.ERROR_PARSE_MANIFEST:
                this.log(`checkout hotupdate code: ${event.getEventCode()} parse remote Manifest failed`);
                newVersionFoud = false;
                break;
            case native.EventAssetsManager.ALREADY_UP_TO_DATE:
                this.log(`checkout hotupdate code: ${event.getEventCode()} already up to date`);
                newVersionFoud = false;
                break;
            case native.EventAssetsManager.ERROR_DECOMPRESS:
                this.log(`checkout hotupdate code: ${event.getEventCode()} decompress failed`);
                newVersionFoud = false;
                break;
            case native.EventAssetsManager.NEW_VERSION_FOUND:
                this.log(`checkout hotupdate code: ${event.getEventCode()} new version found`);
                newVersionFoud = true;
                break;
            case native.EventAssetsManager.UPDATE_PROGRESSION:
                this.log(`checkout hotupdate code: ${event.getEventCode()} update progression`);
                break;
            case native.EventAssetsManager.ASSET_UPDATED:
                this.log(`checkout hotupdate code: ${event.getEventCode()} asset updated`);
                break;
            case native.EventAssetsManager.ERROR_UPDATING:
                this.log(`checkout hotupdate code: ${event.getEventCode()} error updating`);
                break;
            case native.EventAssetsManager.UPDATE_FAILED:
                this.log(`checkout hotupdate code: ${event.getEventCode()} update failed`);
                break;
            case native.EventAssetsManager.UPDATE_FINISHED:
                this.log(`checkout hotupdate code: ${event.getEventCode()} update finish`);
                break;
            default:
                this.log(`checkout hotupdate code: ${event.getEventCode()} unkown error code`);
                break;
        }

        if (newVersionFoud != null) {
            this._am && this._am.setEventCallback(null);
            this._updating = false;
            this.emit(HotUpdateEvent.CheckVersionResult, newVersionFoud);
        }
    }

    /**
     * 热更回调地址
     */
    updateCallback(event: native.EventAssetsManager) {
        let updateOver = false;
        let failed = false;
        let percent: any;
        switch (event.getEventCode()) {
            case native.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
                this.log(`hotupdate code: ${event.getEventCode()} no local Manifest`);
                failed = true;
                break;
            case native.EventAssetsManager.UPDATE_PROGRESSION:
                percent = event.getPercent();
                if (isNaN(percent)) return;
                this.log(`hotupdate procession: ${percent}`);
                this.disPatchRateEvent(percent);
            // 下载失败， 跳过热更新
            case native.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
            case native.EventAssetsManager.ERROR_PARSE_MANIFEST:
                this.log("download manifest failed! skip to hotupdate");
                failed = false;
                break;
            // 已经是最新的
            case native.EventAssetsManager.ALREADY_UP_TO_DATE:
                this.log("already update to date!");
                updateOver = true;
                break;
            // 更新完成
            case native.EventAssetsManager.UPDATE_FINISHED:
                this.disPatchRateEvent(1);
                updateOver = true;
                break;
            // 更新错误
            case native.EventAssetsManager.UPDATE_FAILED:
                this.log(`hotupdate code: ${event.getEventCode()} error: ${event.getMessage()}`)
                this._failCount++;
                this._updating = false;
                this._canRetry = true;
                this.retry();
                break;
            // 更新过程出错
            case native.EventAssetsManager.ERROR_UPDATING:
                this.log(`hotupdate code: ${event.getEventCode()} assert id: ${event.getAssetId()} msg: ${event.getMessage()}`);
                break;
            // 解压错误
            case native.EventAssetsManager.ERROR_DECOMPRESS:
                this.log(`hotupdate code: ${event.getEventCode()} ERROR_DECOMPRESS`);
                break;
            default:
                break;
        }

        if (failed) {
            this._am.setEventCallback(null);
            this._updating = false;
            this.hotUpdateFinish(false);
        }

        if (updateOver) {
            this.hotUpdateFinish(true);
        }
    }

    /**
     * 热更完成
     */
    hotUpdateFinish(result: boolean) {
        this.destory();
        this.emit(HotUpdateEvent.HotUpdateFinish, result);
    }

    destory() {
        this._am && this._am.setEventCallback(null);
        this._am = null;
    }

    /**
     * 重新下载失败
     */
    retry() {
        if (this._failCount > 3) {
            return;
        }
        if (!this._updating && this._canRetry) {
            this._canRetry = false;
            this._am.downloadFailedAssets();
        }
    }

    /**
     * 加载Manifest
     */
    async loadManifest() {
        return new Promise<HotUpateData>((res, rej) => {
            !native.fileUtils.isDirectoryExist(this._storagePath) && native.fileUtils.createDirectory(this._storagePath);
            let manifestData: { [key: string]: any } = {};
            let localManifestPath = `${this._storagePath}/project.manifest`;
            resources.load(`manifest/${this._name}/project`, Asset, (err, resource: Asset) => {
                if (native.fileUtils.isFileExist(localManifestPath)) {
                    let buf = native.fileUtils.getDataFromFile(localManifestPath);
                    manifestData = JSON.parse(this.unit8ArrayToString(new Uint8Array(buf)));
                } else {
                    if (err) { // 本地不存在 manifest 文件
                        manifestData = {
                            packageUrl: "",
                            remoteManifestUrl: "",
                            remoteVersionUrl: "",
                            version: "0",
                            assets: {},
                            searchPaths: new Array(),
                        }
                        manifestData["packageUrl"] = this.packageUrl;
                        manifestData["remoteManifestUrl"] = `${this.packageUrl}project.manifest`;
                        manifestData["remoteVersionUrl"] = `${this.packageUrl}version.manifest`;
                        native.fileUtils.writeStringToFile(JSON.stringify(manifestData), localManifestPath);
                    } else {
                        localManifestPath = resource.nativeUrl
                    }
                }
                console.log("=========resource=========", localManifestPath)
                let localAsset = new HotUpateData();
                localAsset.name = this._name;
                localAsset.packageurl = localManifestPath;
                res(localAsset);
            })
        })
    }

    unit8ArrayToString(array: Uint8Array): string {
        let out: string;
        let i: number;
        let len: number;
        let c: number;
        let char2: number;
        let char3: number;

        out = "";
        len = array.length;
        i = 0;
        while (i < len) {
            c = array[i++];
            switch (c >> 4) {
                case 0:
                case 1:
                case 2:
                case 3:
                case 4:
                case 5:
                case 6:
                case 7:
                    // 0xxxxxxx
                    out += String.fromCharCode(c);
                    break;
                case 12:
                case 13:
                    // 110x xxxx   10xx xxxx
                    char2 = array[i++];
                    out += String.fromCharCode(((c & 0x1f) << 6) | (char2 & 0x3f));
                    break;
                case 14:
                    // 1110 xxxx  10xx xxxx  10xx xxxx
                    char2 = array[i++];
                    char3 = array[i++];
                    out += String.fromCharCode(((c & 0x0f) << 12) | ((char2 & 0x3f) << 6) | ((char3 & 0x3f) << 0));
                    break;
            }
        }

        return out;
    }

    /**
     * 更新热更进度
     */
    disPatchRateEvent(percent: number) {
       this.emit(HotUpdateEvent.HotUpdateRate, percent);
    }

    emit(key: string, ...arg: any[]) {
        director.emit(key, this._name, ...arg)
    }

    getStorePath() {
        return this._storagePath
    }
}
