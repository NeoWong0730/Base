/**
 * 热更服务器地址
 */
export const GameConst = {
    serverip: "http://127.0.0.1:8080"
}