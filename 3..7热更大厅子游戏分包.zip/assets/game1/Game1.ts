import { assetManager } from 'cc';
import { _decorator, Component, director, Node } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('Game1')
export class Game1 extends Component {
    start() {
    }

    update(deltaTime: number) {
    }

    onBack() {
        director.loadScene("Hall", null, () => {
            let bundle = assetManager.getBundle("game1")
            if (bundle) {
                assetManager.removeBundle(bundle)
            }
        })
    }
}

