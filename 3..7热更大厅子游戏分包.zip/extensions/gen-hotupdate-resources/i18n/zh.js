"use strict"; 
module.exports = { 
    open_panel: "热更工具", 
    title: "热更工具",
    description: "热更新生成及配置工具" 
};
