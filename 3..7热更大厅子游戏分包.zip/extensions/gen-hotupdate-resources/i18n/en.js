"use strict";
module.exports={
    open_panel:"Hotupdate tools",
    title: "hotupdate tools",
    description:"hot update configure tools"
};