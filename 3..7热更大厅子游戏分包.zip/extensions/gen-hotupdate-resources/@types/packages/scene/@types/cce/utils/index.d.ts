export declare function promisify(fn: Function): (...args: any[]) => Promise<unknown>;
export declare function isObject(arg: any): boolean;
export declare function isString(arg: any): boolean;
//# sourceMappingURL=index.d.ts.map