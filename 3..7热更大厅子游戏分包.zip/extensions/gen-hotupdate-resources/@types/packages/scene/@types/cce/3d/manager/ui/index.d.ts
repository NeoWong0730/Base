export declare class UIManager {
    alignSelection(type: string): void;
    distributeSelection(type: string): void;
}
declare const _default: UIManager;
export default _default;
//# sourceMappingURL=index.d.ts.map