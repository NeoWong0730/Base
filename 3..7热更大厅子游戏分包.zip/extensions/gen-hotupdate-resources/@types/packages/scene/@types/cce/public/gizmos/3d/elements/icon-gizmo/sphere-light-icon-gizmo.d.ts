import IconGizmoBase from './icon-gizmo-base';
declare class SphereLightIconGizmo extends IconGizmoBase {
    createController(): void;
    updateController(): void;
}
export default SphereLightIconGizmo;
//# sourceMappingURL=sphere-light-icon-gizmo.d.ts.map