import EditComponentAsset from './edit-component-asset';
declare class EditAnimationMask extends EditComponentAsset {
    importSkeleton(prefabUuid: string): Promise<any>;
    /**
     * 清空现有节点
     */
    clearNodes(): any;
}
declare const _default: EditAnimationMask;
export default _default;
//# sourceMappingURL=animation-mask.d.ts.map