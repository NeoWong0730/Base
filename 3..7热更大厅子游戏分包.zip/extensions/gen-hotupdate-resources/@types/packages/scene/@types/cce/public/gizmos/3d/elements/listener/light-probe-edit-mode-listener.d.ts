export default interface LightProbeEditModeListener {
    lightProbeEditModeChanged(mode: boolean): void;
    lightProbeInfoChanged?(): void;
    boundingBoxEditModeChanged?(mode: boolean): void;
}
//# sourceMappingURL=light-probe-edit-mode-listener.d.ts.map