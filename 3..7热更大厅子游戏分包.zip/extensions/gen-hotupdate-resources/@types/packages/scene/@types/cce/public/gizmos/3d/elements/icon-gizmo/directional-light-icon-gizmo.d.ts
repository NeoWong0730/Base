import IconGizmoBase from './icon-gizmo-base';
declare class DirectionalLightIconGizmo extends IconGizmoBase {
    createController(): void;
}
export default DirectionalLightIconGizmo;
//# sourceMappingURL=directional-light-icon-gizmo.d.ts.map