declare module 'vue/dist/vue' {
    import Vue from 'vue';
    export default Vue;
}
