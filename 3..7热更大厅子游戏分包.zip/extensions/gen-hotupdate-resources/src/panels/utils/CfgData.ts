export class CfgData {
    remoteUrl: string = "";
    historyUrls: string[] = [];
    version: string = "1.0.1";
    buildDir: string = "";
    remoteDir: string = "";
    subPackages: string[] = [];
}
