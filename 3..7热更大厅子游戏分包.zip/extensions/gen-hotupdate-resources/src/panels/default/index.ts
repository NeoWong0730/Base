import { readFileSync } from 'fs-extra';
import { join } from 'path';
import Vue from 'vue/dist/vue';
import { CfgUtil } from '../utils/CfgUtil';
import { CfgData } from '../utils/CfgData';
import { existsSync, readdirSync } from 'fs';
import { MetaData } from '../utils/MetaData';
import { generator } from '../utils/version_generator';

Vue.component("subpacakage-item", {
    // template: `
    // <ui-prop slot="label" name="子游戏名">
    //     <ui-label>game1</ui-label>
    //     <ui-button>删除</ui-button>
    // </ui-prop>
    // `,
    template: `
    <div class="shadow" style="width: 95%;margin-left: 20px;margin-top: 10px;">
        <ui-label class="flex-2" style="width: 100px;margin-left: 20px;">{{subpackage}}</ui-label>
        <ui-button class="red"  style="margin-left: 120px;" @click="$emit('remove', subpackage)">删除</ui-button>
    </div>
    `,
    props: ["subpackage"]
})

const component = Vue.extend({
    template: readFileSync(join(__dirname, '../../../static/template/vue/app.html'), 'utf-8'),
    data() {
        return {
            subPackageName: "",
            get rootDir() {
                return join(Editor.Project.path)
            },
            get remoteDir() {
                return join(this.rootDir, "remote")
            },
            mainCfgData: CfgUtil.getCfgData("main"),
            subCfgData: new CfgData(),
            subBundles: [''],
            addMainSubPackage: "",
            logView: ""
        };
    },
    created() {
        this.updateSubPackageList()
    },
    methods: {
        clearLog() {
            this.logView = ""
        },

        generatorMainPackage() {
            generator("main", this.mainCfgData)
            let bFoudHistoryUrl = false
            for (let historyUrl of this.mainCfgData.historyUrls) {
                if (historyUrl == this.mainCfgData.remoteUrl) {
                    bFoudHistoryUrl = true
                }
            }

            if (!bFoudHistoryUrl) {
                this.mainCfgData.historyUrls.push(this.mainCfgData.remoteUrl)
            }
            CfgUtil.saveConfig("main", this.mainCfgData)
            this.logView += `generator main package success!!!\n`
            console.log("generator main package success!!!")
        },

        generatorSubPackage() {
        },

        onMainRemoteUrlChange(url: string) {
            this.mainCfgData.remoteUrl = url
        },

        onMainBuildDirChange(name: string) {
            this.mainCfgData.buildDir = name
        },

        onMainRemoteDirChange(name: string) {
            this.mainCfgData.remoteDir = name
        },

        onMainVersionChange(version: string) {
            this.mainCfgData.version = version
        },

        updateSubPackageList() {
            const assertsDir = join(Editor.Project.path, "assets")
            let directories = readdirSync(assertsDir, {
                encoding: "utf-8",
                withFileTypes: true,
            })
            
            let tempList: string[] = []
            directories.forEach((dir) => {
                if (dir.isDirectory() && !this.isBuiltInBundle(dir.name)) {
                    const metaPath = join(assertsDir, dir.name + ".meta")
                    if (existsSync(metaPath)) {
                        let metaData = new MetaData()
                        let jsonString = readFileSync(metaPath, { encoding: "utf-8" })
                        Object.assign(metaData, JSON.parse(jsonString));
                        if (metaData.userData.isBundle) {
                            tempList.push(metaData.bundleName || dir.name)
                        }
                    }
                }
            })
            this.subBundles = tempList
        },

        onMainSubPackageConfirm(name: string) {
            this.addMainSubPackage = name
        },

        clickAddMainSubPackage() {
            if (!!this.addMainSubPackage) {
                for (let subPackage of this.mainCfgData.subPackages) {
                    if (subPackage === this.addMainSubPackage) {
                        return
                    }
                }
                this.mainCfgData.subPackages.push(this.addMainSubPackage)
            }
        },

        removeSubPackage(name: string) {
            for(let i= 0; i < this.mainCfgData.subPackages.length; i++) {
                if (name === this.mainCfgData.subPackages[i]) {
                    this.mainCfgData.subPackages.splice(i, 1)
                }
            }
        },

        onChangeHistoryConfirm(historyUrl: string) {
            this.mainCfgData.remoteUrl = historyUrl
        },

        /** 子包处理 */
        onSubPackageChange(name: string) {
            this.subPackageName = name
            this.subCfgData =  CfgUtil.getCfgData(name)
        },

        onSubPackageVersionChange(version: string) {
            this.subCfgData.version = version
        },

        onSubPackageHistoryChange(name: string) {
            this.subCfgData.remoteUrl = name
        },

        onSubPackageBuildDir(name: string) {
            this.subCfgData.buildDir = name
        },

        onSubPackageRemoteDir(name: string) {
            this.subCfgData.remoteDir = name
        },

        onSubPackageRemoteUrlChange(url: string) {
            this.subCfgData.remoteUrl = url
        },

        onSubPackageGenerator() {
            generator(this.subPackageName, this.subCfgData)
            let bFoudHistoryUrl = false
            for (let historyUrl of this.subCfgData.historyUrls) {
                if (historyUrl == this.subCfgData.remoteUrl) {
                    bFoudHistoryUrl = true
                }
            }

            if (!bFoudHistoryUrl) {
                this.subCfgData.historyUrls.push(this.subCfgData.remoteUrl)
            }
            CfgUtil.saveConfig(this.subPackageName, this.subCfgData)
            this.logView += `generator ${this.subPackageName} package success!!!\n`
            console.log(`generator ${this.subPackageName} package success!!!`)
        },

        /** 内置asset bundle */
        isBuiltInBundle(name: string) {
            let bundles = ["internal", "main", "resources", "start-scene"]
            return bundles.includes(name)
        }
    },
});
const panelDataMap = new WeakMap() as WeakMap<object, InstanceType<typeof component>>;
/**
 * @zh 如果希望兼容 3.3 之前的版本可以使用下方的代码
 * @en You can add the code below if you want compatibility with versions prior to 3.3
 */
// Editor.Panel.define = Editor.Panel.define || function(options: any) { return options }
module.exports = Editor.Panel.define({
    listeners: {
        show() { console.log('show'); },
        hide() { console.log('hide'); },
    },
    template: readFileSync(join(__dirname, '../../../static/template/default/index.html'), 'utf-8'),
    style: readFileSync(join(__dirname, '../../../static/style/default/index.css'), 'utf-8'),
    $: {
        app: '#app',
        text: '#text',
    },
    methods: {
        hello() {
        },
    },
    ready() {
        if (this.$.app) {
            const vm = new component();
            panelDataMap.set(this, vm);
            vm.$mount(this.$.app);
        }
    },
    beforeClose() { },
    close() {
        const vm = panelDataMap.get(this);
        if (vm) {
            vm.$destroy();
        }
    }
});
