exports.configs = {
    '*': {
        hooks: './builder/hook.js'
    },
};

